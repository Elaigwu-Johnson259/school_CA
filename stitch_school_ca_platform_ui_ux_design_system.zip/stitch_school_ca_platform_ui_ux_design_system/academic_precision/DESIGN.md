---
name: Academic Precision
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45474c'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#545f73'
  primary: '#091426'
  on-primary: '#ffffff'
  primary-container: '#1e293b'
  on-primary-container: '#8590a6'
  inverse-primary: '#bcc7de'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#00190e'
  on-tertiary: '#ffffff'
  tertiary-container: '#00301f'
  on-tertiary-container: '#24a375'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e3fb'
  primary-fixed-dim: '#bcc7de'
  on-primary-fixed: '#111c2d'
  on-primary-fixed-variant: '#3c475a'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  tabular-nums:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: '0'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an authoritative, institutional, and utilitarian environment tailored for K-12 school administrations, academic boards, educators, and pupils. It balances enterprise-grade governance with modern academic agility. 

The aesthetic is anchored in **Corporate / Modern Utilitarianism**:
- **Trust & Authority**: Replaces flashy consumer trends with structural clarity, reliable information density, and precise data hierarchy necessary for grade verification, compliance tracking, and formal transcripts.
- **Cognitive Clarity**: Minimizes cognitive fatigue during mass grading, continuous assessment uploads, and batch report-card generation. Whitespace is functional, not decorative.
- **Workflow Confidence**: Employs decisive, unmistakable status indicators (approved vs. AI-flagged) so educators and registrars can make split-second grading verifications with zero ambiguity.

## Colors

The palette leverages high-contrast institutional slates, focused action blues, and semantic indicators for academic auditing:

- **Institutional Primary (`#1E293B` / `#0F172A`)**: Represents structural governance, applied across core app shells, table headers, primary navigation, and high-emphasis typography.
- **Academic Action Secondary (`#2563EB` / `#1D4ED8`)**: Powers primary commands, student profile links, active tabs, and automated batch trigger buttons.
- **Verification Success (`#059669` / `#10B981`)**: Dedicated strictly to verified Continuous Assessment (CA) scores, approved report cards, attendance validation, and passing thresholds.
- **AI Attention & Warning (`#D97706` / `#F59E0B`)**: Designates pending AI-assisted marking reviews, model confidence flags, and missing student assessment submissions.
- **Critical Negative (`#DC2626`)**: Reserved for grading discrepancies, administrative locks, and failed competencies.
- **Backgrounds & Canvases (`#FFFFFF`, `#F8FAFC`, `#F1F5F9`)**: Clean, crisp, neutral canvases designed for high-density tabular viewports and print-ready digital transcripts.

## Typography

The typographic engine uses **Inter** across all roles to maximize legibility across dense data tables, score matrices, and student performance cards.

- **Tabular Numerals**: Numeric inputs, Continuous Assessment scoring sheets, grade percentiles, and GPA values must always enable OpenType tabular numbers (`tnum`) to maintain vertical alignment across columns.
- **Uppercase Data Labels**: Micro badges and table column headers leverage `label-sm` with slight positive tracking (`+0.04em`) to establish visual anchor points without relying on heavy weights.
- **Hierarchy Separation**: Section groupings in student records must maintain a strict differential between `title-md` (field headers) and `body-md` (entered assessment data).

## Layout & Spacing

This design system uses a structured 12-column fluid grid system on desktop and tablet, collapsing to a single-column stacked layout on mobile:

- **Desktop (>= 1280px)**: 12-column fluid layout with `2rem` outer page margins, `1.5rem` gutters, and a persistent 260px administrative navigation sidebar. Max content wrapper stops at `1600px` for multi-column grading views.
- **Tablet (768px - 1279px)**: 8-column layout with `1.5rem` outer margin and `1rem` gutters; sidebar collapses to an icon-rail navigation to preserve grade sheet real estate.
- **Mobile (< 768px)**: 4-column flow with `1rem` margin and `0.75rem` gutters. Data tables convert to card lists or horizontal swipe matrices.

Vertical spacing follows a strict 4px/8px modular rhythm:
- `space-xs` (4px): Micro gaps between status badge icons and labels.
- `space-sm` (8px): Gaps between form labels and inputs; inner pill padding.
- `space-md` (12px): Standard cell padding for dense grading tables.
- `space-lg` (20px): Card internal padding and fieldset vertical separations.
- `space-xl` (32px): Distance between administrative panels and assessment modules.

## Elevation & Depth

To maintain high data density and professional academic rigor, this design system minimizes heavy drop shadows, relying on **clean tonal layering and low-contrast architectural borders**:

- **Level 0 (Base Canvas)**: Background canvas (`#F8FAFC`). Flat, un-elevated.
- **Level 1 (Card & Table Surfaces)**: Pure white (`#FFFFFF`) framed with a 1px border of `#E2E8F0`. Elevation is entirely border-defined or augmented with a crisp, low-intensity offset shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.05)`.
- **Level 2 (Interactive Floating Elements & Dropdowns)**: Gradebook popovers, class selection dropdowns, and context menus use `#FFFFFF`, a 1px border of `#CBD5E1`, and an ambient shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Modal Sheets & AI Review Drawers)**: Full continuous assessment modals and student performance comparison drawers feature `0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.05)` coupled with an institutional backdrop overlay (`#0F172A` at 45% opacity).

## Shapes

The design system embraces a **Soft (Level 1)** geometric standard. This provides an organized, professional cadence without looking severe or overly playful:

- **Inputs, Buttons, and Table Cells**: Base border radius of `0.25rem` (4px). Provides crisp alignment when nested in continuous assessment grids.
- **Cards, Audit Panels, and Modals**: Styled using `rounded-lg` (`0.5rem` / 8px). Defines comfortable modular separation between administrative units.
- **System Badges & Validation Indicators**: Rendered with `0.25rem` (4px) or full pill geometry strictly for high-visibility AI markers and term status tags.

## Components

### Buttons
- **Primary**: Solid background `#1E293B` (or `#2563EB` for submission triggers) with text `#FFFFFF`. 36px standard height (`space-md` horizontal padding), 4px border radius. Hover states shift one tone darker with no shift in geometry.
- **Secondary / Outline**: 1px border in `#CBD5E1`, background `#FFFFFF`, text `#1E293B`. Hover state applies `#F1F5F9`.
- **Destructive**: Background `#DC2626` or 1px border `#FCA5A5` with red text for grade invalidation.

### Chips & Badges
- **Approved / Verified Grade**: Background `#ECFDF5`, text `#065F46`, border 1px solid `#A7F3D0`.
- **AI Suggested / Pending Teacher Review**: Background `#FFFBEB`, text `#92400E`, border 1px solid `#FDE68A`.
- **Needs Attention**: Background `#FEF2F2`, text `#991B1B`, border 1px solid `#FECACA`.

### Continuous Assessment (CA) Input Grids
- **Score Cells**: Fixed-height (36px), border 1px solid `#CBD5E1`, background `#FFFFFF`. Active focus state features an internal 2px ring of `#2563EB` with text right-aligned using tabular numerals.
- **AI-Predicted Cell**: Marked with a subtle upper-right corner badge in `#F59E0B`. Tab key cycles horizontally through active student entries.

### Checkboxes & Radio Buttons
- 16px square/circle with a 1px border `#94A3B8`. Checked state transitions instantly to `#2563EB` with a crisp white tick.

### Report Card Panels
- Formatted with `#FFFFFF` surfaces, separated by 1px solid `#E2E8F0` divider rules. Section headers feature deep navy labels (`#0F172A`) paired with competency bars utilizing the success emerald (`#059669`) and warning amber (`#D97706`).

### AI Review Split-View
- Dual-pane layout featuring digitized raw student submission alongside the system's extracted marks, accompanied by an explicit "Confirm Grade" or "Override" inline button group.